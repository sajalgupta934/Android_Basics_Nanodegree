package com.business.sajal.quizzapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {
int marksObtained;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private int ques1() {
        CheckBox o1 = (CheckBox) findViewById(R.id.A1);
        CheckBox o2 = (CheckBox) findViewById(R.id.B1);
        CheckBox o3 = (CheckBox) findViewById(R.id.C1);
        CheckBox o4 = (CheckBox) findViewById(R.id.D1);
        int k = 0;
        if (o1.isChecked() && o2.isChecked() && !o3.isChecked() && o4.isChecked())
            k = k + 1;
        return k;

    }
    private int ques2() {
        RadioButton q2 = (RadioButton) findViewById(R.id.radio2A);
        boolean res = q2.isChecked();
        if (res)
            return 1;
        else
            return 0;

    }
    private int ques3() {
        RadioButton q3 = (RadioButton) findViewById(R.id.D3);
        boolean res = q3.isChecked();
        if (res)
            return 1;
        else
            return 0;

    }
    private int ques4() {
        RadioButton q4 = (RadioButton) findViewById(R.id.B4);
        boolean res = q4.isChecked();
        if (res)
            return 1;
        else
            return 0;

    }

    private int ques5()
    {
        EditText count= (EditText) findViewById(R.id.answer5);
String counter = count.getText().toString();
        if(counter.equals("Russia"))
        {
            return 1;
        }
        return 0;
    }
    public void marksGot(View view) {
        marksObtained = 0;
        EditText call = (EditText) findViewById(R.id.name_space);
        String name = call.getText().toString();
        marksObtained = marksObtained + ques1();
        marksObtained = marksObtained + ques2();
        marksObtained = marksObtained + ques3();
        marksObtained = marksObtained + ques4();
        marksObtained = marksObtained + ques5();
        Toast.makeText(this, name + " you scored " + marksObtained + " " + "out of 5", Toast.LENGTH_SHORT).show();
    }
}