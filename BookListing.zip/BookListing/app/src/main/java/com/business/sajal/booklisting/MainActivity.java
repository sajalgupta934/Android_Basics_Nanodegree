package com.business.sajal.booklisting;

import android.content.Context;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView) findViewById(R.id.list_view);


        if (!isNetworkConnected()) {
            TextView mEmptyStateTextView = (TextView) findViewById(R.id.e_view);
            mEmptyStateTextView.setText(R.string.no_connection);
        }
        getData();
    }


    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }

    public void getData() {

        Button search = (Button) findViewById(R.id.search_button);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isNetworkConnected()) {
                    EditText search1 = (EditText) findViewById(R.id.text_search);
                    String searchString = search1.getText().toString();
                    GetData fetch = new GetData();
                    AsyncTask<String, Void, ArrayList<Result>> getData = fetch.execute(searchString);
                    TextView emptyTextView = (TextView) findViewById(R.id.e_view);
                    ;
                    try {
                        if (getData.get() == null) {

                            arrayAdapter = new ArrayAdapter<String>(MainActivity.this,
                                    R.layout.list_item, R.id.text_1, new ArrayList<String>());
                            listView.setAdapter(arrayAdapter);
                            listView.setEmptyView(emptyTextView);

                            Toast.makeText(MainActivity.this, "Your search doesn't have any result, please" +
                                    " enter another search", Toast.LENGTH_SHORT).show();
                        } else {
                            listView.setEmptyView(findViewById(R.id.e_view));
                            String[] authors = new String[getData.get().size()];
                            for (int i = 0; i < getData.get().size(); i++) {
                                authors[i] = "Name: " + String.valueOf(getData.get().get(i).getmTitle()) + "\n" +
                                        "Author: " + String.valueOf(getData.get().get(i).getmAuthor()) + "\n" +
                                        "Pages: " + String.valueOf(getData.get().get(i).getPagecount()) + "\n" +
                                        "Publisher: " + String.valueOf(getData.get().get(i).getmPublisher() + "\n" +
                                        "Rating: " + String.valueOf(getData.get().get(i).getmRating()));
                            }
                            arrayAdapter = new ArrayAdapter<String>(
                                    MainActivity.this,
                                    R.layout.list_item,
                                    R.id.text_1,
                                    authors);
                            if (!arrayAdapter.isEmpty())
                                listView.setAdapter(arrayAdapter);
                            else
                                emptyTextView.setText("DESIRED BOOK NOT FOUND!!");
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(MainActivity.this, " Check Internet with Service Provider", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}