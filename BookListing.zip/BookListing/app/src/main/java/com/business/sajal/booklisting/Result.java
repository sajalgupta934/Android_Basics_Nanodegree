package com.business.sajal.booklisting;

/**
 * Created by sajal on 5/31/2017.
 */
public class Result {
    private String mPagecount;
    private String mTitle;
    private String mRating;
    private String mPublisher;
    private String mAuthor;
    public Result(String desc, String title, String rating, String publisher, String author) {
        mPagecount = desc;
        mTitle = title;
        mRating = rating;
        mPublisher = publisher;
        mAuthor = author;
    }
    public String getPagecount() {
        return mPagecount;
    }
    public String getmTitle() {
        return mTitle;
    }
    public String getmRating() {
        return mRating;
    }
    public String getmPublisher() {
        return mPublisher;
    }
public String getmAuthor() {
        return mAuthor;
    }
}
