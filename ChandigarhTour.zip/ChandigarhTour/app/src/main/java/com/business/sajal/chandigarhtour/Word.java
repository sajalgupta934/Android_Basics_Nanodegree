package com.business.sajal.chandigarhtour;
public class Word {
    private String mPlaceName;
    private String mPlaceDescription;
    private int mImageResourceId = NO_IMAGE_PROVIDED;
    private static final int NO_IMAGE_PROVIDED = -1;
    public Word(String placeName, String placeDescription ) {
        mPlaceName = placeName;
       mPlaceDescription = placeDescription;
    }
    public Word(String placeName, String placeDescription, int imageResourceId) {
        mPlaceName = placeName;
        mPlaceDescription = placeDescription;
        mImageResourceId = imageResourceId;
    }
    public String getPlaceName() {
        return mPlaceName;
    }
    public String getPlaceDescription() {
        return mPlaceDescription;
    }
    public int getImageResourceId() {
        return mImageResourceId;
    }
    public boolean hasImage() {
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }


}