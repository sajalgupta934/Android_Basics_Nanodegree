package com.business.sajal.chandigarhtour;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by sajal on 5/25/2017.
 */

public class RestaurantsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);
        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word((getString(R.string.r1)),(getString(R.string.r1_des)), R.drawable.bbq));
        words.add(new Word((getString(R.string.r2)),(getString(R.string.r2_des)), R.drawable.pirates));
        words.add(new Word((getString(R.string.r3)),(getString(R.string.r3_des)), R.drawable.ovenfresh));
        WordAdapter adapter = new WordAdapter(this, words, R.color.restaurants);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}