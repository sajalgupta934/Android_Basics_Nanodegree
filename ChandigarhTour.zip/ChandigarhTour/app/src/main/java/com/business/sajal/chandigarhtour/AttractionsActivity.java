package com.business.sajal.chandigarhtour;

        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.widget.ListView;
        import java.util.ArrayList;

/**
 * Created by sajal on 5/25/2017.
 */

public class AttractionsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);
        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word((getString(R.string.a1)),(getString(R.string.a1_des)), R.drawable.sukhna_lake));
        words.add(new Word((getString(R.string.a2)),(getString(R.string.a2_des)), R.drawable.open_hand));
        words.add(new Word((getString(R.string.a3)),(getString(R.string.a3_des)), R.drawable.rose_garden));
        words.add(new Word((getString(R.string.a4)),(getString(R.string.a4_des)), R.drawable.rock_garden));
        WordAdapter adapter = new WordAdapter(this, words, R.color.attractions);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
