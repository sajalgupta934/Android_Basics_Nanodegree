package com.business.sajal.chandigarhtour;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by sajal on 5/25/2017.
 */

public class HotelsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);
        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word((getString(R.string.h1)),(getString(R.string.h1_des)), R.drawable.jw_marriot));
        words.add(new Word((getString(R.string.h2)),(getString(R.string.h2_des)), R.drawable.hyatt));
        words.add(new Word((getString(R.string.h3)),(getString(R.string.h3_des)), R.drawable.taj_chd));
        WordAdapter adapter = new WordAdapter(this, words, R.color.hotels);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
