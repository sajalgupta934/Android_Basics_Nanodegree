package com.business.sajal.inventory;

import android.provider.BaseColumns;

/**
 * Created by sajal on 6/15/2017.
 */

public class ContractClass {
    public static final class InventoryEntry implements BaseColumns {
        public static final String PRICE_Column = "price";
        public static final String COLUMN_ID = "id";
        public static final String IMAGE_Image = "image";
        public static final String PRODUCT_NAME_Column = "name";
        public static final String QUANTITY_Column = "quantity";
        public static final String Name_Table = "inventory";
    }

}
