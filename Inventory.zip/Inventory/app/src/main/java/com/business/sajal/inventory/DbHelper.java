package com.business.sajal.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by sajal on 6/15/2017.
 */
public class DbHelper extends SQLiteOpenHelper {
    static final String NAME = "inventory.db";
    private static final int VERSION = 1;

    public DbHelper(Context context) {
        super(context, NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        final String SQL_CREATE_HABIT_TABLE = "CREATE TABLE " + ContractClass.InventoryEntry.Name_Table + " (" +
                ContractClass.InventoryEntry.COLUMN_ID + " INTEGER PRIMARY KEY," +
                ContractClass.InventoryEntry.PRODUCT_NAME_Column + " TEXT NOT NULL, " +
                ContractClass.InventoryEntry.QUANTITY_Column + " INTEGER NOT NULL, " +
                ContractClass.InventoryEntry.PRICE_Column + " INTEGER NOT NULL," +
                ContractClass.InventoryEntry.IMAGE_Image + " BLOB NOT NULL)";
        sqLiteDatabase.execSQL(SQL_CREATE_HABIT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + ContractClass.InventoryEntry.Name_Table);
        onCreate(sqLiteDatabase);
    }


    public boolean insertData(byte[] image, int price, String productName, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ContractClass.InventoryEntry.IMAGE_Image, image);
        contentValues.put(ContractClass.InventoryEntry.PRICE_Column, price);
        contentValues.put(ContractClass.InventoryEntry.PRODUCT_NAME_Column, productName);
        contentValues.put(ContractClass.InventoryEntry.QUANTITY_Column, quantity);
        db.insert(ContractClass.InventoryEntry.Name_Table, null, contentValues);
        return true;
    }


    public Cursor getData(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT * from " + ContractClass.InventoryEntry.Name_Table +
                " WHERE name=\"" + name + "\"", null);
        return res;
    }

    public int deleteEntries() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(ContractClass.InventoryEntry.Name_Table, null, null);
    }


    public boolean deleteData(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(ContractClass.InventoryEntry.Name_Table, "name=?", new String[]{name}) > 0;
    }


    public void updateData(String name, int quantity, int change) {
        SQLiteDatabase db = this.getWritableDatabase();
        String strSQL = "UPDATE " + ContractClass.InventoryEntry.Name_Table + " SET quantity = "
                + (quantity + change) + " WHERE name = \"" + name + "\"";
        db.execSQL(strSQL);
    }

    public ArrayList<String> getAllData() {
        ArrayList<String> productList = new ArrayList<String>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor getList = db.rawQuery("SELECT * FROM " + ContractClass.InventoryEntry.Name_Table, null);
        getList.moveToFirst();
        while (getList.isAfterLast() == false) {
            String productName = getList.getString(getList.getColumnIndex(ContractClass.InventoryEntry.PRODUCT_NAME_Column));
            int quantity = getList.getInt(getList.getColumnIndex(ContractClass.InventoryEntry.QUANTITY_Column));
            int price = getList.getInt(getList.getColumnIndex(ContractClass.InventoryEntry.PRICE_Column));
            productList.add(productName + "\n" + "Quantity: " + quantity + "\n" + "Price: $" + price);
            getList.moveToNext();
        }
        return productList;
    }
}

