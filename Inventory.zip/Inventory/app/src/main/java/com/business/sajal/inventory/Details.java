package com.business.sajal.inventory;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import static android.R.attr.order;

/**
 * Created by sajal on 6/15/2017.
 */

public class Details extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details);

        final DbHelper db = new DbHelper(this);
        Intent getList = getIntent();
        String proName = getList.getExtras().getString("listItem");
        int pos = proName.indexOf("\nQuantity");
        final String subProName = proName.substring(0, pos);

        final Cursor cur = db.getData(subProName);

        if (cur.moveToFirst()) {

            TextView tName = (TextView) findViewById(R.id.text_name);
            tName.setText(subProName);

            int price = cur.getInt(cur.getColumnIndex(ContractClass.InventoryEntry.PRICE_Column));
            TextView tPrice = (TextView) findViewById(R.id.text_price);
            tPrice.setText("$" + price);

            int quantity = cur.getInt(cur.getColumnIndex(ContractClass.InventoryEntry.QUANTITY_Column));
            TextView tQuantity = (TextView) findViewById(R.id.text_quantity);
            tQuantity.setText("" + quantity);
        }

        Button Track = (Button) findViewById(R.id.track);
        Track.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cur.moveToFirst()) {
                    int quantity = cur.getInt(cur.getColumnIndex(ContractClass.InventoryEntry.QUANTITY_Column));
                    if (quantity > 0) {
                        db.updateData(subProName, quantity, -1);
                        quantity = cur.getInt(cur.getColumnIndex(ContractClass.InventoryEntry.QUANTITY_Column));
                        TextView tQuantity = (TextView) findViewById(R.id.text_quantity);
                        tQuantity.setText("" + quantity);
                        Toast.makeText(Details.this, "Refresh the app", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Details.this, "It's empty! Order Now!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        Button ReceiveButton = (Button) findViewById(R.id.receive);
        ReceiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cur.moveToFirst()) {
                    int quantity = cur.getInt(cur.getColumnIndex(ContractClass.InventoryEntry.QUANTITY_Column));
                    db.updateData(subProName, quantity, 1);
                    quantity = cur.getInt(cur.getColumnIndex(ContractClass.InventoryEntry.QUANTITY_Column));
                    TextView tQuantity = (TextView) findViewById(R.id.text_quantity);
                    tQuantity.setText("" + quantity);
                    Toast.makeText(Details.this, "Refresh the app", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button refreshButton = (Button) findViewById(R.id.data_refresh);
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mainIntent = new Intent(Details.this, MainActivity.class);
                startActivity(mainIntent);

            }
        });

        Button orderButton = (Button) findViewById(R.id.order);
        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String productName = "";
                if (cur.moveToFirst()) {
                    productName = cur.getString(cur.getColumnIndex(ContractClass.InventoryEntry.PRODUCT_NAME_Column));
                }
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("message/rfc822");
                intent.putExtra(Intent.EXTRA_TEXT, "Got An Order for " + productName);
                startActivity(Intent.createChooser(intent, "Send Email"));
            }
        });


        Button deleteButton = (Button) findViewById(R.id.data_delete);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case DialogInterface.BUTTON_POSITIVE:
                                if (db.deleteData(subProName)) {
                                    Intent returnHome = new Intent(Details.this, MainActivity.class);
                                    startActivity(returnHome);
                                    Toast.makeText(Details.this, "Deleted!", Toast.LENGTH_SHORT).show();
                                }
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                break;
                        }
                    }
                };
                AlertDialog.Builder ab = new AlertDialog.Builder(Details.this);
                ab.setMessage("Are you sure you want to delete?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();
            }
        });

    }
}
