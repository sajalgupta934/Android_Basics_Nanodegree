package com.business.sajal.inventory;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final DbHelper dataB = new DbHelper(this);


        final ListView listView = (ListView) findViewById(R.id.list_id);
        listView.setEmptyView(findViewById(R.id.empty_field));
        ArrayList<String> list = dataB.getAllData();
        Adapter arrayAdapter = new Adapter(MainActivity.this, list);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent infoIntent = new Intent(MainActivity.this, Details.class);
                String itemSelected = ((TextView) view.findViewById(R.id.track_box)).getText().toString();
                infoIntent.putExtra("listItem", itemSelected);
                startActivity(infoIntent);
            }
        });

        Button add = (Button) findViewById(R.id.button_add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addIntent = new Intent(MainActivity.this, ProAdd.class);
                startActivity(addIntent);
            }
        });

        // Refresh List
        Button refresh = (Button) findViewById(R.id.button_refresh);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final ListView listView1 = (ListView) findViewById(R.id.list_id);
                listView1.setEmptyView(findViewById(R.id.empty_field));
                ArrayList<String> list = dataB.getAllData();
                Adapter arrayAdapter = new Adapter(MainActivity.this, list);
                listView1.setAdapter(arrayAdapter);
                listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        Intent infoIntent = new Intent(MainActivity.this, Details.class);
                        String itemSelected = ((TextView) view.findViewById(R.id.track_box)).getText().toString();
                        infoIntent.putExtra("listItem", itemSelected);
                        startActivity(infoIntent);
                    }
                });
            }
        });

        // Delete Everything
        Button delete = (Button) findViewById(R.id.delete_button);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dataB.deleteEntries();
                Toast.makeText(MainActivity.this, "Data Deleted Please Refresh the List", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

