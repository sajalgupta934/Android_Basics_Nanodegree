package com.business.sajal.sublimemusic;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

/**
 * Created by sajal on 5/12/2017.
 */

public class Albums extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.albums);
        TextView songs = (TextView) findViewById(R.id.songs);
        TextView artists = (TextView) findViewById(R.id.artist);
        TextView playlists = (TextView) findViewById(R.id.playlist);
        TextView current_song = (TextView) findViewById(R.id.current_song);

        current_song.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(Albums.this, MainActivity.class);
                startActivity(j);
            }
        });
        artists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(Albums.this, Artists.class);
                startActivity(j);
            }
        });
        songs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(Albums.this, Songs.class);
                startActivity(j);
            }
        });
        playlists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(Albums.this, Playlists.class);
                startActivity(j);
            }
        });

    }

}
