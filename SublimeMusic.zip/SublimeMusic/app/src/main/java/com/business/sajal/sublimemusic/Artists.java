package com.business.sajal.sublimemusic;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

/**
 * Created by sajal on 5/12/2017.
 */

public class Artists extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.artists);
        TextView songs = (TextView) findViewById(R.id.songs);
        TextView albums = (TextView) findViewById(R.id.album);
        TextView playlists = (TextView) findViewById(R.id.playlist);
        TextView current_song = (TextView) findViewById(R.id.current_song);

        current_song.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(Artists.this, MainActivity.class);
                startActivity(j);
            }
        });
        albums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(Artists.this, Albums.class);
                startActivity(j);
            }
        });
        songs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(Artists.this, Songs.class);
                startActivity(j);
            }
        });
        playlists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(Artists.this, Playlists.class);
                startActivity(j);
            }
        });

    }
}
