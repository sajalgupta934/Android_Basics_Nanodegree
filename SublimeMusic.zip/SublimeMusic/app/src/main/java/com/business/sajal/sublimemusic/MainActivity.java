package com.business.sajal.sublimemusic;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView songs=(TextView) findViewById(R.id.songs);
        TextView albums=(TextView) findViewById(R.id.album);
        TextView artists=(TextView) findViewById(R.id.artist);
        TextView playlists = (TextView) findViewById(R.id.playlist);
        ImageView play = (ImageView) findViewById(R.id.play);
        ImageView next = (ImageView) findViewById(R.id.next);
        ImageView pause = (ImageView) findViewById(R.id.pause);
        ImageView previous = (ImageView) findViewById(R.id.previous);

        songs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j=new Intent(MainActivity.this,Songs.class);
                startActivity(j);
            }
        });
        albums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j=new Intent(MainActivity.this,Albums.class);
                startActivity(j);
            }
        });
        artists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j=new Intent(MainActivity.this,Artists.class);
                startActivity(j);
            }
        });
        playlists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j=new Intent(MainActivity.this,Playlists.class);
                startActivity(j);
            }
        });
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast t=Toast.makeText(getApplicationContext(),"Play Song",Toast.LENGTH_SHORT);
                t.show();
            }
        });
        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast t=Toast.makeText(getApplicationContext(),"Pause Song",Toast.LENGTH_SHORT);
                t.show();
            }
        });
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast t=Toast.makeText(getApplicationContext(),"Previous Song",Toast.LENGTH_SHORT);
                t.show();
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast t=Toast.makeText(getApplicationContext(),"Next Song",Toast.LENGTH_SHORT);
                t.show();
            }
        });

    }
}
