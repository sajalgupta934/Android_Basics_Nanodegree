package com.business.sajal.reportcardclass;

/**
 * Created by sajal on 5/30/2017.
 */

public class ReportCardClass {
    private String name;
    private int mathsGrade;
    private int scienceGrade;
    private int englishGrade;
    private int hindiGrade;
    private int totalGrade;
    private char section;
    public ReportCardClass(char section_of_student,String name_of_student,int marks1,int marks2,
                      int marks3,int marks4){
        name= name_of_student;
        mathsGrade=marks1;
        scienceGrade=marks2;
        englishGrade=marks3;
        hindiGrade=marks4;
        section=section_of_student;
    }
    public String getName() {
        return name;
    }
    public char getSection(){
        return Section;
    }
    public int getMaths(){
        return mathsGrade;
    }
    public int getScience(){
        return scienceGrade;
    }
    public int getEnglish(){
        return englishGrade;
    }
    public int getHindi(){
        return hindiGrade;
    }
    public int getTotal(){
        totalGrade =mathsGrade+scienceGrade+englishGrade+hindiGrade ;
        return totalGrade;
    }
    public double getpercentage(){
        return totalGrade/4;
    }
    public void setName(String name1){
        name=name1;
    }
    public void setSection(char section1){
        section=section1;
    }
    public void setMaths(int marks){
        mathsGrade=marks;
    }
    public void setScience(int marks){
        scienceGrade=marks;
    }
    public void setEnglish(int marks){
        englishGrade=marks;
    }
    public void setHindi(int marks){
        hindiGrade=marks;
    }
    @Override
    public String toString() {
        return "Result [ " +
                "Maths = " + mathsGrade+
                "\nScience = " + scienceGrade +
                "\nEnglish = " + englishGrade +
                "\nHindi = " + hindiGrade +
                "\nTotal = " + totalGrade +
                " ]";
    }
}
