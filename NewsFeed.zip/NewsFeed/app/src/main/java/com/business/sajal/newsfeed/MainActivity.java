package com.business.sajal.newsfeed;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<ArrayList<News>> {
    private static final int DELAY = 30000;
    private static final int LOADER = 0;
    private static final String URL_NEWS = "https://content.guardianapis.com/search?api-key=fe6d87ca-fca8-47cc-af50-22b0e83c6c6d";
    private static final String LOG = "MainActivity.LOG_TAG";


    private ArrayList<News> news;
    private TextView text;
    private SwipeRefreshLayout swipeLayout;
    private ListAdapter Adapter;
    private ListView listView;
    private Handler handler = new Handler();
    private Runnable runnableCode = new Runnable() {
        @Override
        public void run() {

            Log.d("Handlers", "CALLED ON MAIN THREAD");
            refresh();
            handler.postDelayed(runnableCode, DELAY);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        news = new ArrayList<>();

        Adapter = new ListAdapter(this, news);
        listView = (ListView) findViewById(R.id.list_view_default);
        swipeLayout = (SwipeRefreshLayout) findViewById(R.id.swiperefresh);
        text = (TextView) findViewById(R.id.no_data_text_view);
        text.setVisibility(View.GONE);

        listView.setAdapter(Adapter);


        swipeLayout.setOnRefreshListener(
                new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                        Log.i(LOG, "onRefresh called from SwipeRefreshLayout");
                        refresh();
                    }
                }
        );

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String url = news.get(position).getMlink();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });
        handler.post(runnableCode);
    }


    private boolean isNetworkConnected() {

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }

    private void refresh() {
        if (isNetworkConnected()) {
            swipeLayout.post(new Runnable() {
                @Override
                public void run() {
                    swipeLayout.setRefreshing(true);
                }
            });

            handler.removeCallbacks(runnableCode);

            getSupportLoaderManager().initLoader(LOADER, null, this).forceLoad();
        } else {
            text.setText(R.string.device_not_connected);
            text.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        refresh();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public Loader<ArrayList<News>> onCreateLoader(int id, Bundle args) {
        switch (id) {
            case LOADER:

                Log.d(LOG, "onCreateLoader");
                return new ListLoader(this);
            default:

                return null;
        }
    }

    @Override
    public void onLoadFinished(Loader<ArrayList<News>> loader, ArrayList<News> data) {

        swipeLayout.setRefreshing(false);
        news.clear();
        if (data != null) {
            news.addAll(data);
        }
        Adapter.notifyDataSetChanged();
        if (news.size() == 0) {
            text.setText(R.string.data_not_available);
            text.setVisibility(View.VISIBLE);
        } else {
            text.setVisibility(View.GONE);
        }

        handler.postDelayed(runnableCode, DELAY);

    }

    @Override
    public void onLoaderReset(Loader<ArrayList<News>> loader) {
        Log.d(LOG, "Refresh");

    }

    public static class ListLoader extends AsyncTaskLoader<ArrayList<News>> {
        public ListLoader(Context context) {
            super(context);
        }


        @Override
        public ArrayList<News> loadInBackground() {
            Log.d(LOG, "loadInBackground");
            return FetchUtil.News(URL_NEWS);
        }
    }


}
