package com.business.sajal.newsfeed;

import java.util.Date;

/**
 * Created by sajal on 6/10/2017.
 */

public class News {
    private Date mPublishedDate;
    private String mCategory;
    private String mAuthor;
    private String mDescription;
    private String mLink;
    private String mTitle;


    public News(Date publishedDate, String category, String author, String description, String url, String title) {
        mPublishedDate = publishedDate;
        mCategory = category;
        mAuthor = author;
        mDescription = description;
        mLink = url;
        mTitle = title;
    }

    public Date getPublishedDate() {
        return mPublishedDate;
    }


    public String getCategory() {
        return mCategory;
    }

    public String getmAuthor() {
        return mAuthor;
    }

    public String getDescription() {
        return mDescription;
    }


    public String getMlink() {
        return mLink;
    }


    public String getTitle() {
        return mTitle;
    }


}
