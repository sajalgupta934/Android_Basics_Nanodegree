package com.business.sajal.newsfeed;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 * Created by sajal on 6/10/2017.
 */
public class ListAdapter extends ArrayAdapter<News> {

    private final static String FORMAT_DATE = "MM/DD/YYYY ";

    public ListAdapter(Context context, ArrayList<News> news) {
        super(context, 0, news);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        News la = getItem(position);
        ViewHolder view;
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
            view = new ViewHolder();
            view.tvPublishedDate = (TextView) convertView.findViewById(R.id.date_of_publish);
            view.tvCategory = (TextView) convertView.findViewById(R.id.category);
            view.tvAuthor = (TextView) convertView.findViewById(R.id.author_of_news);
            view.tvTitle = (TextView) convertView.findViewById(R.id.title_of_news);
            view.tvDescription = (TextView) convertView.findViewById(R.id.description_of_news);
            convertView.setTag(view);
        } else {

            view = (ViewHolder) convertView.getTag();
        }


        SimpleDateFormat formatter = new SimpleDateFormat(FORMAT_DATE);
        if (la.getPublishedDate() != null) {
            view.tvPublishedDate.setText(formatter.format(la.getPublishedDate()));
        } else {
            view.tvPublishedDate.setText(R.string.no_date);
        }
        view.tvCategory.setText(la.getCategory());
        view.tvAuthor.setText(la.getmAuthor());
        view.tvDescription.setText(la.getDescription());
        view.tvTitle.setText(la.getTitle());
        return convertView;
    }

    static class ViewHolder {

        TextView tvPublishedDate;
        TextView tvCategory;
        TextView tvAuthor;
        TextView tvDescription;
        TextView tvTitle;
    }


}