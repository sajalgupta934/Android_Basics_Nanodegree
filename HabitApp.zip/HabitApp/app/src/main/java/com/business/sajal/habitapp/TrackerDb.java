package com.business.sajal.habitapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by sajal on 6/9/2017.
 */

public class TrackerDb extends SQLiteOpenHelper {
    static final String NAME = "Tracker.db";
    private static final int VERSION = 1;

    public TrackerDb(Context context) {
        super(context, NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        final String SQL_HABIT_TABLE = "CREATE TABLE " + Tracker.Habit.NAME_OF_TABLE + " (" +
                Tracker.Habit.ID + " INTEGER PRIMARY KEY," +
                Tracker.Habit.NAME_COLUMN + " TEXT UNIQUE NOT NULL, " +
                Tracker.Habit.HABIT_COLUMN + " TEXT NOT NULL, " +
                Tracker.Habit.FREQUENCY_COLUMN + "INTEGER NOT NULL," + " );";
        sqLiteDatabase.execSQL(SQL_HABIT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int k, int k2) {

        sqLiteDatabase.execSQL("Drop Table if Exists " + Tracker.Habit.NAME_OF_TABLE);
        onCreate(sqLiteDatabase);
    }


    public boolean insertData(int id, String name, String habit, int frequency) {

        SQLiteDatabase la = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Tracker.Habit.ID, id);
        contentValues.put(Tracker.Habit.NAME_COLUMN, name);
        contentValues.put(Tracker.Habit.HABIT_COLUMN, habit);
        contentValues.put(Tracker.Habit.FREQUENCY_COLUMN, frequency);
        la.insert(Tracker.Habit.NAME_OF_TABLE, null, contentValues);
        la.close();
        return true;
    }

    public Cursor getData(String name) {
        SQLiteDatabase la = this.getReadableDatabase();
        Cursor result = la.rawQuery("SELECT * from " + Tracker.Habit.NAME_OF_TABLE + " WHERE name=" + name, null);
        la.close();
        return result;
    }


    public int deleteAllEntries() {
        SQLiteDatabase la = this.getWritableDatabase();
        return la.delete(Tracker.Habit.NAME_OF_TABLE, null, null);
    }


    public boolean deleteDatabase(Context context) {
        return context.deleteDatabase(Tracker.Habit.NAME_OF_TABLE);
    }

    public boolean updateData(int id, String name, String habit, int frequnecy) {
        SQLiteDatabase la = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Tracker.Habit.ID, id);
        contentValues.put(Tracker.Habit.NAME_COLUMN, name);
        contentValues.put(Tracker.Habit.HABIT_COLUMN, habit);
        contentValues.put(Tracker.Habit.FREQUENCY_COLUMN, frequnecy);
        la.update(Tracker.Habit.NAME_OF_TABLE, contentValues, " id = ? ",new String[]{Integer.toString(id)});
        la.close();
        return true;
    }


}

