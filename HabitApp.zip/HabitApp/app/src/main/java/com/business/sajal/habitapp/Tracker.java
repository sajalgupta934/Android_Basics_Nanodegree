package com.business.sajal.habitapp;

import android.provider.BaseColumns;

/**
 * Created by sajal on 6/9/2017.
 */

public class Tracker {
    public static final class Habit implements BaseColumns {

        public static final String ID = "id";
        public static final String NAME_OF_TABLE = "Habit Tracker";
        public static final String FREQUENCY_COLUMN = "Frequency";
        public static final String HABIT_COLUMN = "Habit";
        public static final String NAME_COLUMN = "Name";

    }
}